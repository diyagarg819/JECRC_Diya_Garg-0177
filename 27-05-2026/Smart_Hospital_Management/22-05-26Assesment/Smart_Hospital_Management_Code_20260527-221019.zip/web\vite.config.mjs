import { defineConfig } from 'vite';
export default defineConfig({
  plugins: [],
  resolve: {
    preserveSymlinks: true
  },
  optimizeDeps: {
    noDiscovery: true,
    include: []
  },
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:5187',
      '/hubs': {
        target: 'http://localhost:5187',
        ws: true
      }
    }
  }
});
